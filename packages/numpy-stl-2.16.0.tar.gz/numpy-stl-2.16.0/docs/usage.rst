
.. include :: ../README.rst

