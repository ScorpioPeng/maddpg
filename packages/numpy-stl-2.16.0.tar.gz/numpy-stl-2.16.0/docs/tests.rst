tests and examples
==================

tests.stl_corruption module
---------------------------

.. literalinclude:: ../tests/stl_corruption.py

tests.test_commandline module
-----------------------------

.. literalinclude:: ../tests/test_commandline.py

tests.test_convert module
-------------------------

.. literalinclude:: ../tests/test_convert.py

tests.test_mesh module
----------------------

.. literalinclude:: ../tests/test_mesh.py

tests.test_multiple module
--------------------------

.. literalinclude:: ../tests/test_multiple.py

tests.test_rotate module
------------------------

.. literalinclude:: ../tests/test_rotate.py

